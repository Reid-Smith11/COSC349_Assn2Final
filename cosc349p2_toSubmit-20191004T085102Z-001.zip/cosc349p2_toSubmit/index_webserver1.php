<?php include "../inc/dbinfo.inc"; ?>
<html>
<body>
<h1>Video Link Saver</h1>

<h4>Save links to your favorite videos to watch later</h4>

<?php

  /* Connect to MySQL and select the database. */
  $connection = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD);

  if (mysqli_connect_errno()) echo "Failed to connect to MySQL: " . mysqli_connect_error();

  $database = mysqli_select_db($connection, DB_DATABASE);

  /* Ensure that the VIDEOS table exists. */
  VerifyVideosTable($connection, DB_DATABASE);

  /* If input fields are populated, add a row to the VIDEOS  table. */
  $video_name = htmlentities($_POST['NAME']);
  $video_url = htmlentities($_POST['URL']);

  if (strlen($video_name) || strlen($video_url)) {
    Addvideo($connection, $video_name, $video_url);
  }
?>

<!-- Input form -->
<form action="<?PHP echo $_SERVER['SCRIPT_NAME'] ?>" method="POST">
  <table border="0">
    <tr>
      <td>NAME</td>
      <td>URL</td>
    </tr>
    <tr>
      <td>
        <input type="text" name="NAME" maxlength="255" size="30" />
      </td>
      <td>
        <input type="text" name="URL" maxlength="1024" size="60" />
      </td>
      <td>
        <input type="submit" value="Add Link" />
      </td>
    </tr>
  </table>
</form>
<br> <form action="http://ec2-3-231-22-126.compute-1.amazonaws.com/index.php">
	<input type="submit" value="See my playlist" />
	</form>
<!-- Clean up. -->
<?php

  mysqli_free_result($result);
  mysqli_close($connection);

?>
<br><br><font size="1">Created by Jack Kearney, Isaac Caruso, and Reid Smith <br>

</body>
</html>


<?php

/* Add an employee to the table. */
function Addvideo($connection, $name, $URL) {
   $n = mysqli_real_escape_string($connection, $name);
   $a = mysqli_real_escape_string($connection, $URL);

   $query = "INSERT INTO VIDEOS (NAME, URL) VALUES ('$n', '$a');";

   if(!mysqli_query($connection, $query)) echo("<p>Error adding video data.</p>");
}

/* Check whether the table exists and, if not, create it. */
function VerifyVideosTable($connection, $dbName) {
	  
if(!TableExists("VIDEOS", $connection, $dbName))
  {
	
     $query = "CREATE TABLE VIDEOS (
         ID int(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
         NAME VARCHAR(255),
         URL VARCHAR(1024)
       )";

     if(!mysqli_query($connection, $query)) echo("<p>Error creating table.</p>");
  }
}

/* Check for the existence of a table. */
function TableExists($tableName, $connection, $dbName) {
  $t = mysqli_real_escape_string($connection, $tableName);
  $d = mysqli_real_escape_string($connection, $dbName);

  $checktable = mysqli_query($connection,
      "SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_NAME = '$t' AND TABLE_SCHEMA = '$d'");

  if(mysqli_num_rows($checktable) > 0) return true;

  return false;
}
?>                        
