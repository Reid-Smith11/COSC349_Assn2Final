<?php include "../inc/dbinfo.inc"; ?>
<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD);

// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

$database = mysqli_select_db($link, DB_DATABASE);


// Attempt Playlist deletion
$sql = "TRUNCATE table VIDEOS";
if(mysqli_query($link, $sql)){
    echo "Playlist cleared!";
} else{
    echo "ERROR: Was not able to execute $sql. " . mysqli_error($link);
}

// Close connection
mysqli_close($link);
?>

<form action="http://ec2-18-208-199-159.compute-1.amazonaws.com">
    <input type="submit" value="Add more videos" />
</form>
